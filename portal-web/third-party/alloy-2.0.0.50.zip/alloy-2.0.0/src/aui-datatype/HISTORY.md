# AUI DataType

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-datatype).

## @VERSION@

	* [AUI-1864](https://issues.liferay.com/browse/AUI-1864) Method "countDays()" created to get the whole number of days between two dates.
	* #AUI-978 DateParser is returning the current date when the parsing fails
