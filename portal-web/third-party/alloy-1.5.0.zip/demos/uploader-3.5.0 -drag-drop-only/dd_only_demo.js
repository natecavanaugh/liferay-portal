YUI().use("yui-base" , "uploader", function(Y) {
	// Y.Uploader.TYPE = 'flash';
	Y.one("#overallProgress").set("text", "Uploader type: " + Y.Uploader.TYPE);
	if (Y.Uploader.TYPE == "html5" && !Y.UA.ios) {
		var uploader = new Y.Uploader(
			{
				appendNewFiles: false,
				errorAction: 'restartasap',
				// width: "0px", 
				// height: "0px", 
				multipleFiles: true,
				swfURL: "http://yui.yahooapis.com/3.5.0/build/uploader/assets/flashuploader.swf?t=" + Math.random(),
				uploadURL: "http://www.yswfblog.com/upload/simpleupload.php",
				simLimit: 1
			}
		);

		window.uploader = uploader;

		var uploadDone = false;

		var documentElement = document.documentElement;

		var bodyNode = Y.one(documentElement);

		documentElement.addEventListener(
			'dragover',
			function(event) {
				event.stopPropagation();
				event.preventDefault();
				event.dataTransfer.dropEffect = 'copy';
			},
			false
		);

		if (Y.Uploader.TYPE == "html5") {
			// uploader.set("dragAndDropArea", "body");
			var docElement = document.documentElement;

			var docElementNode = Y.one(docElement);

			uploader.set("dragAndDropArea", docElementNode);

			uploader.on(["dragenter", "dragover"], function (event) {
				var ddmessage = Y.one("#ddmessage");
				if (ddmessage) {
					ddmessage.setContent("<strong>Files detected, drop them here!</strong>");
					ddmessage.addClass("yellowBackground");
				}
			});

			uploader.on("dragleave", function (event) {
				var ddmessage = Y.one("#ddmessage");
				if (ddmessage) {
					ddmessage.setContent("<strong>Drag and drop files here.</strong>");
					ddmessage.removeClass("yellowBackground");
				}
			});
		}

		uploader.render();

		uploader.get('selectFilesButton').hide();

		uploader.after("fileselect", function (event) {
			console.log('after file select event: ', event);
			var fileList = event.fileList;

			var fileTable = Y.one("#filenames tbody");
			if (fileList.length > 0 && Y.one("#nofiles")) {
				Y.one("#nofiles").remove();
			}

			if (uploadDone) {
				uploadDone = false;
				fileTable.setContent("");
			}

			Y.each(fileList, function (fileInstance) {
				fileTable.append("<tr id='" + fileInstance.get("id") + "_row" + "'>" + 
					"<td class='filename'>" + fileInstance.get("name") + "</td>" + 
					"<td class='filesize'>" + fileInstance.get("size") + "</td>" + 
					"<td class='percentdone'>Hasn't started yet</td></tr>");
				
				var button = Y.Node.create('<button type="button" id="' + fileInstance.get("id") + '" class="yui3-button" style="width:400px; height:35px;">Cancel ' + fileInstance.get("name") + '</button>');

				var body = Y.one(document.body);
				body.append(button);

				button.on("click", function() {
					var queue = uploader.queue;

					queue.cancelUpload(fileInstance);

					var bytesUploaded = fileInstance.get('bytesUploaded');

					if (bytesUploaded > 0 && fileList.length > 1) {

						queue._startNextFile();
					}
					
					if (fileList.length === 1) {
						uploader.fire('alluploadscomplete');
						uploader.queue = null;
					}
				});
			});
		});

		uploader.on("uploadprogress", function (event) {
			var fileRow = Y.one("#" + event.file.get("id") + "_row");
			fileRow.one(".percentdone").set("text", event.percentLoaded + "%");
		});

		uploader.on("uploadstart", function (event) {
			var fileList = uploader.get('fileList');
			uploader.set("enabled", false);
		});

		uploader.on("uploadcomplete", function (event) {
			// console.log('uploadcomplete event: ', event);
			var fileList = uploader.get('fileList');
			// console.log('fileList: ', fileList);
			var fileRow = Y.one("#" + event.file.get("id") + "_row");
			fileRow.one(".percentdone").set("text", "Finished!");
		});

		uploader.on("totaluploadprogress", function (event) {
			Y.one("#overallProgress").setContent("Total uploaded: <strong>" + 
				event.percentLoaded + "%" + 
				"</strong>");
		});

		uploader.on("alluploadscomplete", function (event) {
			// console.log('alluploadscomplete event: ', event);
			uploader.set("enabled", true);
			uploader.set("fileList", []);
			Y.one("#overallProgress").set("text", "Uploads complete!");
			uploadDone = true;
		
		});

		Y.one("#uploadFilesButton").on("click", function () {
			// console.log('uploadDone: ', uploadDone);
			var fileList = uploader.get('fileList');
			// console.log('fileList: ', fileList);
			if (!uploadDone && fileList.length > 0) {
				// if (uploader.queue) {
				// 	uploader.queue.queuedFiles = uploader.get("fileList");
				// 	uploader.queue._startNextFile();
				// }
				// else {
					uploader.uploadAll();
				// }				
			}
		});      

		Y.one("#cancelFilesButton").on("click", function () {
			if (uploader.queue) {
				var queue = uploader.queue;

				queue.cancelUpload();
			}
		});
	} 
	else {
		Y.one("#uploaderContainer").set("text", "We are sorry, but the uploader technology is not supported" + 
			" on this platform.");
	}


});
/*
BUG 1234
	status: fixed

	problem:
		no longer able to upload files

	reproduce:
		1. add a single file in temp
		2. cancel it
		3. try to add any number of files

BUG 1235
	status: fixed

	problem:
		first file upload cannot be cancelled

	reproduce:
		1. add 3 "large" uploads
		2. cancel the last
		3. try to cancel the first

	observation:
		both the first and second uploads begin depsite the first upload's prior cancellation...
		find when the fileList is including the cancelled file
			then deal with it

BUG 1236
	status: open

	problem:
		attempting to upload 3 files will skip the first file upload

	reproduce:
		1. add a single file
		2. upload it
		3. cancel it
		4. repeat steps 1-3
		5. add 3 more files
		6. click upload


Unable to upload any number of files after (uploading a single, cancelling it) x 2

And along with setting "appendNewFiles: false" on Uploader instantiation, this will take care of the bug in the multi-files uploader demo:

BUG 1237
	status: open

	problem:
		unable to upload any number of files

	reproduce:
		1. add a single file
		2. upload it
		3. cancel it
		4. repeat steps 1-3 once
		5. add another single file
		6. click upload
*/