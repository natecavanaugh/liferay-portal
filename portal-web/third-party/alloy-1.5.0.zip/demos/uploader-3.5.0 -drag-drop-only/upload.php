<?php

error_reporting(E_ALL);

print_r(checkFiles($_FILES, "."));

function checkFiles($filearr, $uploaddir, $requireimage=false, $filter=array())
{
	$maxsize = ini_get("upload_max_filesize");
	$final = array('errors' => array(),
		'files' => array(),
		'result' => array()
		);
	foreach($filearr as $input => $filearray){
//for every file upload field
		if(is_array($filter)){
			$use = !in_array($input, $filter) ? true : false;
		} else {
			$use = !preg_match($filter, $input) ? true : false;
		}
		if($use){
			foreach($filearray as $ind => $val){
				//for every element in each upload
				if ($ind == "name") {
					
					$file_pieces = remExtension($val, true);
					if(count($file_pieces) == 2){
						$val = dirify($file_pieces[0]).$file_pieces[1];
					}
					
					$name = time().'_'.$val;

					if (strpos($name, "[") !== FALSE) {
						exit("492");
					}
				}
				if ($ind == "tmp_name") {
					$tmp_name = $val;
				}
				if ($ind == "size") {
					$size = $val;
				}
				if ($ind == "type") {
					$type = $val;
				}
				if ($ind == "error") {
					$error = $val;
				}
			}
			if (file_exists($tmp_name)) {
				$final['files'][$input] = $_FILES[$input];
				$final['files'][$input]['name'] = $name;
				unset($final['files'][$input]['tmp_name']);
				$max_size = (isset($_POST['MAX_FILE_SIZE'])) ? $_POST['MAX_FILE_SIZE'] : (intval(ini_get('upload_max_filesize')) * 1024 * 1024);
				if ($size > $max_size) {
					if ($max_size < 1024) {
						$maxfilesize = "$max_size bytes";
					} else if ($max_size < 1048576) {
						$maxfilesize = number_format($max_size/1024) ." KB";
					} else {
						$maxfilesize = number_format($max_size/1048576) ." MB";
					}
					$final['errors'][$input][] = sprintf(L_ERR_UPLOAD_HEAVY, $name, $maxsize);
				} else if ($final['files'][$input]['error'] == 1) {
					$final['errors'][$input][] = sprintf(L_ERR_UPLOAD_HEAVY, $name, $maxsize);
				}
				if ($requireimage) {
					if (!getimagesize($tmp_name)) {
						$final['errors'][$input][] = sprintf(L_ERR_UPLOAD_NOT_IMAGE, $name);
					}
				}
				if (!empty($final['errors'])) {
					$final['result'][$input]['uploaded'] = 0;
				} else {
					if (is_dir($uploaddir)) {
						$upfile = "$uploaddir/$name";
						if (move_uploaded_file($tmp_name, $upfile)) {
							if (substr(sprintf('%o', fileperms($upfile)), -3) < 644) {
								chmod($upfile, 0644);
							}
							$final['result'][$input]['uploaded'] = 1;
							if (getimagesize($upfile)) {
								$dims = getimagesize($upfile);
								$final['files'][$input]['width'] = $dims[0];
								$final['files'][$input]['height'] = $dims[1];
							}
						} else {
							$final['result'][$input]['uploaded'] = 0;
						}
					} else {
						$final['result'][$input]['uploaded'] = 0;
						$final['errors'][$input][] = L_ERR_UPLOAD_MISSING_DIR;
					}
				}
			}
}// filter
}
return $final;
}

function dirify($s) {
	$s = convert_high_ascii($s);  
	$s = strtolower($s);           
	$s = strip_tags($s);       
	$s = preg_replace('!&[^;\s]+;!','',$s);
	$s = preg_replace('![^\w\s-]!','',$s);           
	$s = preg_replace('![\s]+!','-',$s);           
	return $s;    
}

function remExtension($name, $return_parts=false){ 
	$ext = strrchr($name, '.'); 
	if($return_parts){
		return ($ext !== false) ? array(substr($name, 0, -strlen($ext)), $ext) : array($name); 
	}
	return ($ext !== false) ? substr($name, 0, -strlen($ext)) : $name; 
}

function convert_high_ascii($s) {
	$HighASCII = array(
		"\xc3\x80" => "A",
		"\xc3\x81" => "A",
		"\xc3\x82" => "A",
		"\xc3\x83" => "A",
		"\xc3\x84" => "A",
		"\xc3\x85" => "A",
		"\xc4\x80" => "A",
		"\xc4\x82" => "A",
		"\xc4\x84" => "A",
		"\xc7\x8d" => "A",
		"\xc7\x9e" => "A",
		"\xc7\xa0" => "A",
		"\xc7\xba" => "A",
		"\xc8\x80" => "A",
		"\xc8\x82" => "A",
		"\xc8\xa6" => "A",
		"\xc3\xa0" => "a",
		"\xc3\xa1" => "a",
		"\xc3\xa2" => "a",
		"\xc3\xa3" => "a",
		"\xc3\xa4" => "a",
		"\xc4\x81" => "a",
		"\xc4\x83" => "a",
		"\xc4\x85" => "a",
		"\xc7\x8e" => "a",
		"\xc7\x9f" => "a",
		"\xc7\xa0" => "a",
		"\xc7\xbb" => "a",
		"\xc8\x81" => "a",
		"\xc8\x83" => "a",
		"\xc8\xa7" => "a",
		"\xc9\x90" => "a",
		"\xc9\x91" => "a",
		"\xc9\x92" => "a",
		"\xc3\x86" => "Ae",
		"\xc7\xa2" => "Ae",
		"\xc7\xbc" => "AE",
		"\xc3\xa6" => "ae",
		"\xc7\xa3" => "ae",
		"\xc7\xbd" => "ae",
		"\xc6\x81" => "B",
		"\xc6\x82" => "B",
		"\xc9\x93" => "B",
		"\xc6\x80" => "b",
		"\xc6\x83" => "b",
		"\xca\x99" => "b",
		"\xc3\x87" => "C",
		"\xc4\x86" => "C",
		"\xc4\x88" => "C",
		"\xc4\x8a" => "C",
		"\xc4\x8c" => "C",
		"\xc6\x87" => "C",
		"\xc3\xa7" => "c",
		"\xc4\x87" => "c",
		"\xc4\x89" => "c",
		"\xc4\x8b" => "c",
		"\xc4\x8d" => "c",
		"\xc6\x88" => "c",
		"\xc9\x95" => "c",
		"\xca\x97" => "c",
		"\xc3\x90" => "D",
		"\xc4\x8e" => "D",
		"\xc4\x90" => "D",
		"\xc6\x89" => "D",
		"\xc6\x8a" => "D",
		"\xc6\x8b" => "D",
		"\xc3\xb0" => "d",
		"\xc4\x8f" => "d",
		"\xc4\x91" => "d",
		"\xc6\x8c" => "d",
		"\xc6\x8d" => "d",
		"\xc8\xa1" => "d",
		"\xc9\x96" => "d",
		"\xc9\x97" => "d",
		"\xc7\x84" => "DZ",
		"\xc7\x85" => "DZ",
		"\xc7\xb1" => "DZ",
		"\xc7\xb2" => "DZ",
		"\xc7\x86" => "dz",
		"\xc7\xb3" => "dz",
		"\xca\xa3" => "dz",
		"\xca\xa4" => "dz",
		"\xca\xa5" => "dz",

		"\xc3\x88" => "E",
		"\xc3\x89" => "E",
		"\xc3\x8a" => "E",
		"\xc3\x8b" => "E",
		"\xc4\x92" => "E",
		"\xc4\x94" => "E",
		"\xc4\x96" => "E",
		"\xc4\x98" => "E",
		"\xc4\x9a" => "E",
		"\xc6\x8e" => "E",
		"\xc6\x8f" => "E",
		"\xc6\x90" => "E",
		"\xc8\x84" => "E",
		"\xc8\x86" => "E",
		"\xc8\xba" => "E",
		"\xc3\xa8" => "e",
		"\xc3\xa9" => "e",
		"\xc3\xaa" => "e",
		"\xc3\xab" => "e",
		"\xc4\x93" => "e",
		"\xc4\x95" => "e",
		"\xc4\x97" => "e",
		"\xc4\x99" => "e",
		"\xc4\x9b" => "e",
		"\xc7\x9d" => "e",
		"\xc8\x85" => "e",
		"\xc8\x87" => "e",
		"\xc8\xbb" => "e",
		"\xc9\x98" => "e",
		"\xc9\x99" => "e",
		"\xc9\x9a" => "e",
		"\xc9\x9b" => "e",
		"\xc9\x9c" => "e",
		"\xc9\x9d" => "e",
		"\xc9\x9e" => "e",
		"\xca\x9d" => "e",
		"\xc6\x91" => "F",
		"\xc6\x92" => "f",
		"\xc9\xb8" => "f",
		"\xca\xa9" => "fg",
		"\xc4\x9c" => "G",
		"\xc4\x9e" => "G",
		"\xc4\xa0" => "G",
		"\xc4\xa2" => "G",
		"\xc6\x93" => "G",
		"\xc6\x94" => "G",
		"\xc7\xa4" => "G",
		"\xc7\xa6" => "G",
		"\xc7\xb4" => "G",
		"\xc4\x9d" => "g",
		"\xc4\x9f" => "g",
		"\xc4\xa1" => "g",
		"\xc4\xa3" => "g",
		"\xc7\xa5" => "g",
		"\xc7\xa7" => "g",
		"\xc7\xb5" => "g",
		"\xc9\xa0" => "g",
		"\xc9\xa1" => "g",
		"\xc9\xa2" => "g",
		"\xc9\xa3" => "g",
		"\xca\x9c" => "g",
		"\xc4\xa4" => "H",
		"\xc4\xa6" => "H",
		"\xc7\xb6" => "H",
		"\xc8\x9e" => "H",
		"\xc4\xa5" => "h",
		"\xc4\xa7" => "h",
		"\xc6\x95" => "h",
		"\xc8\xa5" => "h",
		"\xc9\xa6" => "h",
		"\xc9\xa7" => "h",
		"\xca\x9c" => "h",
		"\xca\xae" => "h",
		"\xca\xaf" => "h",
		"\xc3\x8c" => "I",
		"\xc3\x8d" => "I",
		"\xc3\x8e" => "I",
		"\xc3\x8f" => "I",
		"\xc4\xa8" => "I",
		"\xc4\xaa" => "I",
		"\xc4\xac" => "I",
		"\xc4\xae" => "I",
		"\xc4\xb0" => "I",
		"\xc6\x96" => "I",
		"\xc6\x97" => "I",
		"\xc7\x8f" => "I",
		"\xc8\x88" => "I",
		"\xc8\x8a" => "I",
		"\xc3\xac" => "i",
		"\xc3\xad" => "i",
		"\xc3\xae" => "i",
		"\xc3\xaf" => "i",
		"\xc4\xa9" => "i",
		"\xc4\xab" => "i",
		"\xc4\xad" => "i",
		"\xc4\xaf" => "i",
		"\xc4\xb1" => "i",
		"\xc7\x90" => "i",
		"\xc8\x89" => "i",
		"\xc8\x8b" => "i",
		"\xc9\xa8" => "i",
		"\xc9\xa9" => "i",
		"\xc9\xaa" => "i",
		"\xc4\xb2" => "IJ",
		"\xc4\xb3" => "ij",
		"\xc4\xb4" => "J",
		"\xc4\xb5" => "j",
		"\xc7\xb0" => "j",
		"\xc9\x9f" => "j",
		"\xca\x84" => "j",
		"\xca\x9d" => "j",
		"\xc4\xb6" => "K",
		"\xc6\x98" => "K",
		"\xc7\xa8" => "K",
		"\xc4\xb7" => "k",
		"\xc4\xb8" => "k",
		"\xc6\x99" => "k",
		"\xc7\xa9" => "k",
		"\xca\x9e" => "k",
		"\xc4\xb9" => "L",
		"\xc4\xbb" => "L",
		"\xc4\xbd" => "L",
		"\xc4\xbf" => "L",
		"\xc5\x81" => "L",
		"\xc8\xb4" => "L",
		"\xc4\xba" => "l",
		"\xc4\xbc" => "l",
		"\xc4\xbe" => "l",
		"\xc5\x80" => "l",
		"\xc5\x82" => "l",
		"\xc6\x9a" => "l",
		"\xc6\x9b" => "l",
		"\xc9\xab" => "l",
		"\xc9\xac" => "l",
		"\xc9\xad" => "l",
		"\xc9\xae" => "l",
		"\xca\x9f" => "l",
		"\xc7\x87" => "LJ",
		"\xc7\x88" => "LJ",
		"\xc7\x89" => "lj",
		"\xca\xaa" => "ls",
		"\xca\xab" => "lz",
		"\xc6\x9c" => "M",
		"\xc9\xaf" => "m",
		"\xc9\xb0" => "m",
		"\xc9\xb1" => "m",
		"\xc3\x91" => "N",
		"\xc5\x83" => "N",
		"\xc5\x85" => "N",
		"\xc5\x87" => "N",
		"\xc5\x8a" => "N",
		"\xc6\x9d" => "N",
		"\xc8\xa0" => "N",
		"\xc3\xb1" => "n",
		"\xc5\x84" => "n",
		"\xc5\x86" => "n",
		"\xc5\x88" => "n",
		"\xc5\x89" => "n",
		"\xc5\x8b" => "n",
		"\xc6\xb5" => "n",
		"\xc8\xb4" => "n",
		"\xc9\xb2" => "n",
		"\xc9\xb3" => "n",
		"\xc9\xb4" => "n",
		"\xc7\x8a" => "NJ",
		"\xc7\x8b" => "NJ",
		"\xc7\xb8" => "NJ",
		"\xc7\x8c" => "nj",
		"\xc7\xb9" => "nj",
		"\xc3\x92" => "O",
		"\xc3\x93" => "O",
		"\xc3\x94" => "O",
		"\xc3\x95" => "O",
		"\xc3\x96" => "O",
		"\xc3\x97" => "O",
		"\xc5\x8c" => "O",
		"\xc5\x8e" => "O",
		"\xc5\x90" => "O",
		"\xc6\x86" => "O",
		"\xc6\x9f" => "O",
		"\xc6\xa0" => "O",
		"\xc7\xb9" => "O",
		"\xc7\xaa" => "O",
		"\xc7\xac" => "O",
		"\xc7\xbe" => "O",
		"\xc8\x8c" => "O",
		"\xc8\x8e" => "O",
		"\xc8\xaa" => "O",
		"\xc8\xac" => "O",
		"\xc8\xae" => "O",
		"\xc8\xb0" => "O",
		"\xc3\xb2" => "o",
		"\xc3\xb3" => "o",
		"\xc3\xb4" => "o",
		"\xc3\xb5" => "o",
		"\xc3\xb6" => "o",
		"\xc3\xb7" => "o",
		"\xc5\x8d" => "o",
		"\xc5\x8f" => "o",
		"\xc5\x91" => "o",
		"\xc6\xa1" => "o",
		"\xc7\x92" => "o",
		"\xc7\xab" => "o",
		"\xc7\xad" => "o",
		"\xc7\xbf" => "o",
		"\xc8\x8d" => "o",
		"\xc8\x8f" => "o",
		"\xc8\xab" => "o",
		"\xc8\xad" => "o",
		"\xc8\xaf" => "o",
		"\xc8\xb1" => "o",
		"\xc9\x94" => "o",
		"\xc9\xb5" => "o",
		"\xc6\xa2" => "OI",
		"\xc6\xa3" => "oi",
		"\xc5\x92" => "Oe",
		"\xc5\x93" => "oe",
		"\xc9\xb6" => "oe",
		"\xc9\xb7" => "oe",
		"\xc6\xa5" => "P",
		"\xca\xa0" => "q",
		"\xc5\x94" => "R",
		"\xc5\x96" => "R",
		"\xc5\x98" => "R",
		"\xc6\xa6" => "R",
		"\xc8\x90" => "R",
		"\xc8\x92" => "R",
		"\xc5\x95" => "r",
		"\xc5\x97" => "r",
		"\xc5\x99" => "r",
		"\xc8\x91" => "r",
		"\xc8\x93" => "r",
		"\xc9\xb9" => "r",
		"\xc9\xba" => "r",
		"\xc9\xbb" => "r",
		"\xc9\xbc" => "r",
		"\xc9\xbd" => "r",
		"\xc9\xbe" => "r",
		"\xca\x80" => "r",
		"\xca\x81" => "r",
		"\xc3\x9f" => "S",
		"\xc5\x9a" => "S",
		"\xc5\x9c" => "S",
		"\xc5\x9e" => "S",
		"\xc5\xa0" => "S",
		"\xc6\xa7" => "S",
		"\xc6\xa9" => "S",
		"\xc8\x98" => "S",
		"\xc5\x9b" => "s",
		"\xc5\x9d" => "s",
		"\xc5\x9f" => "s",
		"\xc5\xa1" => "s",
		"\xc6\xa8" => "s",
		"\xc6\xaa" => "s",
		"\xc8\x99" => "s",
		"\xca\x82" => "s",
		"\xca\x83" => "s",
		"\xca\x84" => "s",
		"\xca\x85" => "s",
		"\xc3\x9e" => "T",
		"\xc5\xa2" => "T",
		"\xc5\xa4" => "T",
		"\xc5\xa6" => "T",
		"\xc6\xac" => "T",
		"\xc6\xae" => "T",
		"\xc8\x9a" => "T",
		"\xc3\xbe" => "t",
		"\xc5\xa3" => "t",
		"\xc5\xa5" => "t",
		"\xc5\xa7" => "t",
		"\xc6\xab" => "t",
		"\xc6\xad" => "t",
		"\xc8\x9b" => "t",
		"\xc8\xb6" => "t",
		"\xca\x87" => "t",
		"\xca\x88" => "t",
		"\xca\xa8" => "tc",
		"\xca\xa6" => "ts",
		"\xca\xa7" => "ts",
		"\xc3\x99" => "U",
		"\xc3\x9a" => "U",
		"\xc3\x9b" => "U",
		"\xc3\x9c" => "U",
		"\xc5\xa8" => "U",
		"\xc5\xaa" => "U",
		"\xc5\xac" => "U",
		"\xc5\xae" => "U",
		"\xc5\xb0" => "U",
		"\xc5\xb2" => "U",
		"\xc6\xaf" => "U",
		"\xc6\xb1" => "U",
		"\xc7\x93" => "U",
		"\xc7\x95" => "U",
		"\xc7\x97" => "U",
		"\xc7\x99" => "U",
		"\xc7\x9b" => "U",
		"\xc8\x94" => "U",
		"\xc8\x96" => "U",
		"\xc8\xa2" => "U",
		"\xc3\xb9" => "u",
		"\xc3\xba" => "u",
		"\xc3\xbb" => "u",
		"\xc3\xbc" => "u",
		"\xc5\xa9" => "u",
		"\xc5\xab" => "u",
		"\xc5\xad" => "u",
		"\xc5\xaf" => "u",
		"\xc5\xb1" => "u",
		"\xc5\xb3" => "u",
		"\xc6\xb0" => "u",
		"\xc7\x94" => "u",
		"\xc7\x96" => "u",
		"\xc7\x98" => "u",
		"\xc7\x9a" => "u",
		"\xc7\x9c" => "u",
		"\xc8\x95" => "u",
		"\xc8\x97" => "u",
		"\xc8\xa3" => "u",
		"\xca\x89" => "u",
		"\xca\x8a" => "u",
		"\xca\x8b" => "u",
		"\xc6\xb2" => "V",
		"\xca\x8c" => "v",
		"\xc5\xb4" => "W",
		"\xc7\xb7" => "W",
		"\xc5\xb5" => "w",
		"\xca\x8d" => "w",
		"\xc3\x9d" => "Y",
		"\xc5\xb6" => "Y",
		"\xc5\xb8" => "Y",
		"\xc6\xb3" => "Y",
		"\xc8\x9c" => "Y",
		"\xc8\xb2" => "Y",
		"\xc3\xbe" => "y",
		"\xc3\xbf" => "y",
		"\xc5\xb7" => "y",
		"\xc6\xb4" => "y",
		"\xc8\x9d" => "y",
		"\xc8\xb3" => "y",
		"\xca\x8e" => "y",
		"\xca\x8f" => "y",
		"\xc5\xb9" => "Z",
		"\xc5\xbb" => "Z",
		"\xc5\xbd" => "Z",
		"\xc6\xb5" => "Z",
		"\xc6\xb7" => "Z",
		"\xc6\xb9" => "Z",
		"\xc7\xae" => "Z",
		"\xc8\xa4" => "Z",
		"\xc5\xba" => "z",
		"\xc5\xbc" => "z",
		"\xc5\xbe" => "z",
		"\xc6\xb6" => "z",
		"\xc6\xb8" => "z",
		"\xc6\xba" => "z",
		"\xc7\xaf" => "z",
		"\xc8\xa4" => "z",
		"\xca\x90" => "z",
		"\xca\x91" => "z",
		"\xca\x92" => "z",
		"\xca\x93" => "z",
		"\xc6\xbb" => "2",
		"\xc6\xbc" => "5",
		"\xc6\xbd" => "5",
		"\xc6\x84" => "6",
		"\xc6\x85" => "6",
		);
foreach($HighASCII as $ind=>$val){
	$HighASCII2["/".$ind."/"] = $val;
}
$find = array_keys($HighASCII2);
$replace = array_values($HighASCII2);
$s = preg_replace($find,$replace,$s);
return $s;
}
?>