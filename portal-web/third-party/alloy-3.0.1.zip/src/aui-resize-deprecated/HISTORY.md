aui-resize-deprecated
========
