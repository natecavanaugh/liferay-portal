﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'zh-cn', {
	bulletedlist: '项目列表',
	numberedlist: '编号列表'
});
