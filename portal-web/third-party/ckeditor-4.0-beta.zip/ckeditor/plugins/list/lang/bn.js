﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'bn', {
	bulletedlist: 'বুলেট লিস্ট লেবেল',
	numberedlist: 'সাংখ্যিক লিস্টের লেবেল'
});
