﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'horizontalrule', 'hi', {
	toolbar: 'हॉरिज़ॉन्टल रेखा इन्सर्ट करें'
});
