﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ku', {
	copy: 'مافی لهبهرگرتنهوهی &copy; $1. گشتی پارێزراوه.',
	dlgTitle: 'دهربارهی CKEditor',
	help: 'سهیری $1 بکه بۆ یارمهتی.',
	moreInfo: 'بۆ زانیاری زیاتری مۆڵهت, تکایه سهردانی ماڵپهڕهکهمان بکه:',
	title: 'دهربارهی CKEditor',
	userGuide: 'ڕێپیشاندهری CKEditors'
});
