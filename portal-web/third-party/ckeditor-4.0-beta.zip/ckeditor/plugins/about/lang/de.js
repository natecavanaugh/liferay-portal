﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'de', {
	copy: 'Copyright &copy; $1. Alle Rechte vorbehalten.',
	dlgTitle: 'Über CKEditor',
	help: 'Prüfe $1 für Hilfe.',
	moreInfo: 'Für Informationen über unsere Lizenzbestimmungen besuchen sie bitte unsere Webseite:',
	title: 'Über CKEditor',
	userGuide: 'CKEditor Benutzerhandbuch'
});
