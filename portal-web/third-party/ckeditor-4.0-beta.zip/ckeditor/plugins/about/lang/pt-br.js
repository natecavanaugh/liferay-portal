﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'pt-br', {
	copy: 'Copyright &copy; $1. Todos os direitos reservados.',
	dlgTitle: 'Sobre o CKEditor',
	help: 'Verifique o $1 para obter ajuda.',
	moreInfo: 'Para informações sobre a licença por favor visite o nosso site:',
	title: 'Sobre o CKEditor',
	userGuide: 'Guia do Usuário do CKEditor'
});
