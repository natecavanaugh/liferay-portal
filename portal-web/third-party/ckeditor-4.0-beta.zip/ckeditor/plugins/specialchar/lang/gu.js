﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'gu', {
	options: 'સ્પેશિઅલ કરેક્ટરના વિકલ્પો',
	title: 'સ્પેશિઅલ વિશિષ્ટ અક્ષર પસંદ કરો',
	toolbar: 'વિશિષ્ટ અક્ષર ઇન્સર્ટ/દાખલ કરવું'
});
