﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ms', {
	options: 'Special Character Options', // MISSING
	title: 'Sila pilih huruf istimewa',
	toolbar: 'Masukkan Huruf Istimewa'
});
