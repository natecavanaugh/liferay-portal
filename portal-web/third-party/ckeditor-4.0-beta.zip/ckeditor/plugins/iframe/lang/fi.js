﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fi', {
	border: 'Näytä kehyksen reunat',
	noUrl: 'Anna IFrame-kehykselle lähdeosoite (src)',
	scrolling: 'Näytä vierityspalkit',
	title: 'IFrame-kehyksen ominaisuudet',
	toolbar: 'IFrame-kehys'
});
