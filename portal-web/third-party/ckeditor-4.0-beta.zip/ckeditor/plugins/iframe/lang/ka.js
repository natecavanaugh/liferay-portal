﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ka', {
	border: 'ჩარჩოს გამოჩენა',
	noUrl: 'აკრიფეთ iframe-ის URL',
	scrolling: 'გადახვევის ზოლების დაშვება',
	title: 'IFrame-ის პარამეტრები',
	toolbar: 'IFrame'
});
