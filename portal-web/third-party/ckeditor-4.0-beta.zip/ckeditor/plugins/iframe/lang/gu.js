﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'gu', {
	border: 'ફ્રેમ બોર્ડેર બતાવવી',
	noUrl: 'iframe URL ટાઈપ્ કરો',
	scrolling: 'સ્ક્રોલબાર ચાલુ કરવા',
	title: 'IFrame વિકલ્પો',
	toolbar: 'IFrame'
});
