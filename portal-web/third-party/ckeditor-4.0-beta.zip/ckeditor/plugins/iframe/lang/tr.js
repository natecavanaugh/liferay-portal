﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'tr', {
	border: 'Çerceve sınırlarını göster',
	noUrl: 'Lütfen IFrame köprü (URL) bağlantısını yazın',
	scrolling: 'Kaydırma çubuklarını aktif et',
	title: 'IFrame Özellikleri',
	toolbar: 'IFrame'
});
