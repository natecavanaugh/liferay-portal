﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sk', {
	border: 'Zobraziť orámovanie',
	noUrl: 'Vložte URL pre iframe',
	scrolling: 'Povoliť skrolovanie',
	title: 'IFrame - vlastnosti',
	toolbar: 'IFrame' // MISSING
});
