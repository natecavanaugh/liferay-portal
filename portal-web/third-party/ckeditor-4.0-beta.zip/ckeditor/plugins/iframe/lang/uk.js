﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'uk', {
	border: 'Показати рамки фрейму',
	noUrl: 'Будь ласка введіть посилання для IFrame',
	scrolling: 'Увімкнути прокрутку',
	title: 'Налаштування для IFrame',
	toolbar: 'IFrame'
});
