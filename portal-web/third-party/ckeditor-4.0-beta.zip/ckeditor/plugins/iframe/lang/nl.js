﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'nl', {
	border: 'Framerand tonen',
	noUrl: 'Geef de IFrame URL in',
	scrolling: 'Scrollbalken inschakelen',
	title: 'IFrame eigenschappen',
	toolbar: 'IFrame'
});
