﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'zh-cn', {
	border: '显示框架边框',
	noUrl: '请输入框架的 URL',
	scrolling: '允许滚动条',
	title: 'IFrame 属性',
	toolbar: 'IFrame'
});
