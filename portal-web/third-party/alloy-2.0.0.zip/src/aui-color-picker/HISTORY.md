AUI Color Picker
========

@VERSION@
------
	* #AUI-1083 - Color picker value slider does not update results preview
	* #AUI-1091 - Update the selected value on typing custom color in HEX input field
	* #AUI-983 - ColorPickerPopover does not display properly when more than one node is set as trigger
